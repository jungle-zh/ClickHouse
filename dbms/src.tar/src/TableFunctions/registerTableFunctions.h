#pragma once

namespace DB
{

void registerTableFunctions();

}
