int mainEntryClickHousePerformanceTest(int argc, char ** argv);
int main(int argc_, char ** argv_) { return mainEntryClickHousePerformanceTest(argc_, argv_); }
