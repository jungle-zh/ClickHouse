int mainEntryClickHouseCompressor(int argc, char ** argv);
int main(int argc_, char ** argv_) { return mainEntryClickHouseCompressor(argc_, argv_); }
