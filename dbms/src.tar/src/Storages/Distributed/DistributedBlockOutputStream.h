#pragma once

#include <Parsers/formatAST.h>
#include <DataStreams/IBlockOutputStream.h>
#include <Core/Block.h>
#include <Common/Throttler.h>
#include <common/ThreadPool.h>
#include <atomic>
#include <memory>
#include <chrono>
#include <optional>
#include <Interpreters/Cluster.h>
#include <Interpreters/Context.h>
#include <Functions/IFunction.h>

namespace Poco
{
    class Logger;
}

namespace DB
{

class StorageDistributed;

/** If insert_sync_ is true, the write is synchronous. Uses insert_timeout_ if it is not zero.
 *  Otherwise, the write is asynchronous - the data is first written to the local filesystem, and then sent to the remote servers.
 *  If the Distributed table uses more than one shard, then in order to support the write,
 *  when creating the table, an additional parameter must be specified for ENGINE - the sharding key.
 *  Sharding key is an arbitrary expression from the columns. For example, rand() or UserID.
 *  When writing, the data block is splitted by the remainder of the division of the sharding key by the total weight of the shards,
 *  and the resulting blocks are written in a compressed Native format in separate directories for sending.
 *  For each destination address (each directory with data to send), a separate thread is created in StorageDistributed,
 *  which monitors the directory and sends data. */
class DistributedBlockOutputStream : public IBlockOutputStream
{
public:
    DistributedBlockOutputStream(StorageDistributed & storage, const ASTPtr & query_ast, const ClusterPtr & cluster_,
                                 const Settings & settings_, bool insert_sync_, UInt64 insert_timeout_);

    DistributedBlockOutputStream(StorageDistributed * storage ,const ClusterPtr & cluster_,
                                 const Settings & settings, bool insert_sync_, UInt64 insert_timeout_
            ,Protocol::Client::Enum query_type  = Protocol::Client::Query ,const String & shuffle_table_name = "" );

    void shuffleWrite(Block & block, const Names & key_names ,const  Context & context) ;
    Block getHeader() const override;
    void write(const Block & block) override;
    void writeShuffleRemote(const Block & block,const  IColumn::Selector & selector);
    void writePrefix() override;

    void writeSuffix() override;
    void writeSuffixForce();
    //void writeSuffixShuffleMainTable();
    //void writeSuffixShuffleRightTable();

    IColumn::Selector createSelectorShuffleRemote(const Block & source_block ,const  Names &   key_names ,const Context  & context);


private:

    IColumn::Selector createSelector(const Block & source_block);

    void writeAsync(const Block & block);

    /// Split block between shards.
    Blocks splitBlock(const Block & block);

    void writeSplitAsync(const Block & block);

    void writeAsyncImpl(const Block & block, const size_t shard_id = 0);

    /// Increments finished_writings_count after each repeat.
    void writeToLocal(const Block & block, const size_t repeats);

    void writeToShard(const Block & block, const std::vector<std::string> & dir_names);


    /// Performs synchronous insertion to remote nodes. If timeout_exceeded flag was set, throws.
    void writeSync(const Block & block);

    void initWritingJobs(const Block & first_block);

    struct JobReplica;
    ThreadPool::Job runWritingJob(JobReplica & job, const Block & current_block );

    void waitForJobs();

    /// Returns the number of blocks was written for each cluster node. Uses during exception handling.
    std::string getCurrentStateDescription();

private:

    StorageDistributed * storage;
    ASTPtr query_ast;
    const ClusterPtr  cluster;
    const Settings & settings;
   // Context  context;
    size_t inserted_blocks = 0;
    size_t inserted_rows = 0;

    bool insert_sync;
    Protocol::Client::Enum  query_type;
    String shuffle_table_name;

    /// Sync-related stuff
    UInt64 insert_timeout; // in seconds
    Stopwatch watch;
    Stopwatch watch_current_block;
    std::optional<ThreadPool> pool;
    ThrottlerPtr throttler;
    String query_string;

    struct JobReplica
    {
        JobReplica() = default;
        JobReplica(size_t shard_index, size_t replica_index, bool is_local_job, const Block & sample_block)
            : shard_index(shard_index), replica_index(replica_index), is_local_job(is_local_job), current_shard_block(sample_block.cloneEmpty()) {}

        size_t shard_index = 0;
        size_t replica_index = 0;
        bool is_local_job = false;

        Block current_shard_block;

        ConnectionPool::Entry connection_entry;
        std::unique_ptr<Context> local_context;
        BlockOutputStreamPtr stream;

        UInt64 blocks_written = 0;
        UInt64 rows_written = 0;

        UInt64 blocks_started = 0;
        UInt64 elapsed_time_ms = 0;
        UInt64 max_elapsed_time_for_block_ms = 0;
    };

    struct JobShard
    {
        std::list<JobReplica> replicas_jobs;
        IColumn::Permutation shard_current_block_permuation;
    };

    std::vector<JobShard> per_shard_jobs;

    size_t remote_jobs_count = 0;
    size_t local_jobs_count = 0;
    
    std::atomic<unsigned> finished_jobs_count{0};

    Poco::Logger * log;
};

}
