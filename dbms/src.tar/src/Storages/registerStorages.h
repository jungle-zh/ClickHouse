#pragma once

namespace DB
{

void registerStorages();

}
